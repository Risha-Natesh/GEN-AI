
import React from 'react';
import Ticker from './components/Ticker';
import Scoreboard from './components/Scoreboard';
import StadiumArena from './components/StadiumArena';
import CardCreator from './components/CardCreator';

const App: React.FC = () => {
  return (
    <div className="min-h-screen selection:bg-yellow-400 selection:text-black">
      {/* Header & Score Ticker */}
      <header className="sticky top-0 z-50 bg-slate-950/90 backdrop-blur-md border-b-2 border-slate-800">
        <div className="container mx-auto px-4 py-4 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center space-x-3">
            <div className="bg-yellow-400 p-2 rounded-lg rotate-12">
              <i className="fas fa-baseball-bat-ball text-black text-3xl"></i>
            </div>
            <div>
              <h1 className="text-2xl font-black italic tracking-tighter text-white">
                CRICKET <span className="text-yellow-400">CHAOS</span>
              </h1>
              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Stadium Edition v1.0</p>
            </div>
          </div>
          
          <div className="hidden md:flex items-center space-x-6">
            <nav className="flex space-x-6 text-sm font-bold uppercase tracking-widest">
              <a href="#arena" className="text-yellow-400 hover:text-white transition-colors">Arena</a>
              <a href="#forge" className="text-slate-400 hover:text-white transition-colors">AI Forge</a>
              <a href="#leaderboard" className="text-slate-400 hover:text-white transition-colors">Legends</a>
            </nav>
            <button className="bg-red-600 hover:bg-red-500 text-white px-6 py-2 rounded-full font-black text-xs transition-all shadow-lg shadow-red-600/20">
              JOIN MATCH
            </button>
          </div>
        </div>
        <Ticker />
      </header>

      <main className="container mx-auto px-4 py-12 space-y-12">
        {/* Hero Section */}
        <section className="flex flex-col lg:flex-row gap-12 items-center">
          <div className="w-full lg:w-1/2 space-y-8">
            <div className="inline-block bg-orange-600/20 text-orange-500 px-4 py-1 rounded-full text-xs font-black uppercase tracking-widest border border-orange-600/30">
              Season Final: Mumbai vs Sydney
            </div>
            <h1 className="text-6xl md:text-8xl font-black italic leading-[0.9] tracking-tighter">
              BATTLE FOR <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500">
                GLORY!
              </span>
            </h1>
            <p className="text-xl text-slate-400 font-medium max-w-lg leading-relaxed">
              Step into the heart of the action. Smashing sixes, taking wickets, and becoming the legendary player you were born to be. 
            </p>
            <div className="flex gap-4">
              <button className="bg-white text-black px-8 py-4 rounded-xl font-black text-lg hover:bg-yellow-400 transition-all shadow-xl active:scale-95">
                START BATTING
              </button>
              <button className="bg-slate-800 text-white px-8 py-4 rounded-xl font-black text-lg border-2 border-slate-700 hover:bg-slate-700 transition-all active:scale-95">
                VIEW REPLAYS
              </button>
            </div>
          </div>

          <div className="w-full lg:w-1/2 flex justify-center">
            <Scoreboard />
          </div>
        </section>

        {/* Interactive Arena */}
        <section id="arena" className="py-8">
          <StadiumArena />
        </section>

        {/* AI Card Creator */}
        <section id="forge" className="py-8">
          <CardCreator />
        </section>

        {/* Fun Stats Grid */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-6 py-8">
          {[
            { label: "STADIUM NOISE", val: "128dB", icon: "fa-volume-high", color: "text-red-400" },
            { label: "WICKETS FALLEN", val: "4,201", icon: "fa-skull", color: "text-purple-400" },
            { label: "HYPE LEVEL", val: "MAXIMUM", icon: "fa-fire", color: "text-orange-400" }
          ].map((stat, i) => (
            <div key={i} className="bg-slate-900 border-2 border-slate-800 p-6 rounded-2xl flex items-center space-x-6 transform hover:-translate-y-2 transition-transform">
              <div className={`text-4xl ${stat.color}`}>
                <i className={`fas ${stat.icon}`}></i>
              </div>
              <div>
                <div className="text-xs font-black text-slate-500 uppercase tracking-widest">{stat.label}</div>
                <div className="text-3xl font-black text-white">{stat.val}</div>
              </div>
            </div>
          ))}
        </section>
      </main>

      <footer className="bg-slate-950 border-t-4 border-yellow-400 pt-16 pb-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            <div className="col-span-1 md:col-span-2 space-y-6">
               <div className="flex items-center space-x-3">
                <i className="fas fa-baseball-bat-ball text-yellow-400 text-3xl"></i>
                <h2 className="text-2xl font-black text-white italic">CRICKET CHAOS</h2>
              </div>
              <p className="text-slate-500 max-w-md">
                The world's most high-energy cricket fan experience. Built for those who eat, sleep, and breathe the gentleman's game (played with ungentlemanly intensity).
              </p>
            </div>
            <div>
              <h3 className="text-white font-black uppercase text-sm mb-6 tracking-widest">RESOURCES</h3>
              <ul className="space-y-4 text-slate-500 font-bold text-sm">
                <li><a href="#" className="hover:text-yellow-400 transition-colors">STADIUM RULES</a></li>
                <li><a href="#" className="hover:text-yellow-400 transition-colors">COACHING CLINIC</a></li>
                <li><a href="#" className="hover:text-yellow-400 transition-colors">FAN MERCH</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-black uppercase text-sm mb-6 tracking-widest">SOCIALS</h3>
              <div className="flex space-x-4">
                {['fa-twitter', 'fa-instagram', 'fa-youtube', 'fa-tiktok'].map(icon => (
                  <a key={icon} href="#" className="w-10 h-10 bg-slate-900 flex items-center justify-center rounded-lg hover:bg-yellow-400 hover:text-black transition-all">
                    <i className={`fab ${icon}`}></i>
                  </a>
                ))}
              </div>
            </div>
          </div>
          <div className="border-t border-slate-900 pt-8 flex flex-col md:flex-row justify-between items-center text-slate-600 text-[10px] font-black uppercase tracking-[0.2em]">
            <p>© 2024 CRICKET CHAOS INTERACTIVE. ALL RIGHTS RESERVED.</p>
            <p>MADE FOR THE LOVE OF THE GAME 🏏🔥</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
