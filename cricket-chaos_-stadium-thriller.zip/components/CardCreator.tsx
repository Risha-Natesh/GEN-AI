
import React, { useState } from 'react';
import { generateCricketImage } from '../services/geminiService';
import { CricketCard } from '../types';
import { RARITIES } from '../constants';

const CardCreator: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [cards, setCards] = useState<CricketCard[]>([]);

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    const imageUrl = await generateCricketImage(prompt);
    
    if (imageUrl) {
      const newCard: CricketCard = {
        id: Date.now().toString(),
        imageUrl,
        prompt,
        rarity: RARITIES[Math.floor(Math.random() * RARITIES.length)],
        stats: {
          batting: Math.floor(Math.random() * 21) + 80,
          bowling: Math.floor(Math.random() * 21) + 80,
          swag: Math.floor(Math.random() * 21) + 80,
        }
      };
      setCards(prev => [newCard, ...prev]);
    }
    setLoading(false);
    setPrompt('');
  };

  return (
    <div className="w-full bg-slate-800 rounded-3xl p-8 border-4 border-slate-700 shadow-2xl">
      <div className="flex flex-col md:flex-row gap-8 items-start">
        <div className="w-full md:w-1/2 space-y-6">
          <h2 className="text-4xl font-black text-yellow-400 tracking-tight">AI CARD FORGE 🛠️</h2>
          <p className="text-slate-400 font-medium">
            Type your wildest cricket dreams. Futuristic stadiums? Retro street cricket? Space cricket? 
            Generate a unique collectible card!
          </p>
          
          <div className="space-y-4">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g. A futuristic robot hitting a helicopter shot in a stadium on Mars with neon lights..."
              className="w-full bg-slate-900 border-2 border-slate-700 rounded-xl p-4 text-white focus:border-yellow-400 focus:outline-none h-32 transition-colors"
            />
            <button
              onClick={handleGenerate}
              disabled={loading}
              className={`w-full py-4 rounded-xl font-black text-xl flex items-center justify-center space-x-3 transform active:scale-95 transition-all
                ${loading ? 'bg-slate-700 cursor-not-allowed' : 'bg-gradient-to-r from-yellow-500 to-orange-600 hover:from-yellow-400 hover:to-orange-500 text-black shadow-lg shadow-orange-500/20'}`}
            >
              {loading ? (
                <>
                  <i className="fas fa-circle-notch fa-spin"></i>
                  <span>FORGING LEGEND...</span>
                </>
              ) : (
                <>
                  <i className="fas fa-magic"></i>
                  <span>GENERATE CARD</span>
                </>
              )}
            </button>
          </div>
        </div>

        <div className="w-full md:w-1/2 flex flex-col items-center justify-center min-h-[300px] border-2 border-dashed border-slate-700 rounded-3xl p-4 bg-slate-900/50 overflow-hidden">
          {cards.length === 0 && !loading ? (
            <div className="text-center text-slate-500 space-y-4">
              <i className="fas fa-id-card text-6xl"></i>
              <p className="font-bold">Your collection starts here...</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-8 w-full place-items-center">
              {loading && (
                <div className="animate-pulse bg-slate-700 w-[240px] h-[340px] rounded-2xl flex items-center justify-center">
                   <div className="text-slate-500 text-sm font-black">MANIFESTING...</div>
                </div>
              )}
              {cards.map(card => (
                <div key={card.id} className="relative group perspective-1000">
                  <div className={`relative w-[280px] h-[400px] rounded-2xl overflow-hidden border-8 transition-transform group-hover:scale-105 duration-500
                    ${card.rarity === 'Legendary' ? 'border-yellow-400 shadow-[0_0_30px_rgba(250,204,21,0.4)]' : 
                      card.rarity === 'Epic' ? 'border-purple-500 shadow-[0_0_25px_rgba(168,85,247,0.4)]' :
                      card.rarity === 'Rare' ? 'border-blue-400 shadow-[0_0_20px_rgba(96,165,250,0.4)]' : 'border-slate-500'}`}>
                    
                    <img src={card.imageUrl} alt="Cricket AI" className="w-full h-full object-cover" />
                    
                    <div className="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-black/70 text-[10px] font-black text-white uppercase border border-white/20">
                      {card.rarity}
                    </div>

                    <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black via-black/80 to-transparent p-4">
                      <div className="flex justify-between items-end">
                        <div className="space-y-1">
                          <div className="text-[10px] font-bold text-slate-400 uppercase">PLAYER CLASS</div>
                          <div className="text-white font-black text-lg leading-tight truncate w-32">{card.prompt.split(' ').slice(0, 3).join(' ')}</div>
                        </div>
                        <div className="flex flex-col items-end">
                          <div className="text-yellow-400 font-black text-2xl leading-none">{card.stats.swag}</div>
                          <div className="text-[8px] font-bold text-slate-400">SWAG</div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-white/10">
                        <div className="text-center">
                          <div className="text-white font-bold text-sm">{card.stats.batting}</div>
                          <div className="text-[8px] text-slate-400 uppercase font-black tracking-widest">BAT</div>
                        </div>
                        <div className="text-center">
                          <div className="text-white font-bold text-sm">{card.stats.bowling}</div>
                          <div className="text-[8px] text-slate-400 uppercase font-black tracking-widest">BOWL</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CardCreator;
