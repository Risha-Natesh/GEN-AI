
import React, { useState, useEffect } from 'react';
import { MatchScore } from '../types';

const Scoreboard: React.FC = () => {
  const [score, setScore] = useState<MatchScore>({
    runs: 182,
    wickets: 7,
    overs: "18.4",
    required: 24,
    ballsLeft: 8
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setScore(prev => {
        // Randomly simulate balls passing
        const isRun = Math.random() > 0.4;
        const runsScored = isRun ? Math.floor(Math.random() * 7) : 0;
        const isWicket = !isRun && Math.random() > 0.8;
        
        let newOvers = parseFloat(prev.overs);
        let currentBall = Math.round((newOvers % 1) * 10);
        currentBall++;
        if (currentBall >= 6) {
          newOvers = Math.floor(newOvers) + 1;
        } else {
          newOvers = Math.floor(newOvers) + (currentBall / 10);
        }

        return {
          ...prev,
          runs: prev.runs + runsScored,
          wickets: prev.wickets + (isWicket ? 1 : 0),
          overs: newOvers.toFixed(1),
          required: Math.max(0, prev.required - runsScored),
          ballsLeft: Math.max(0, prev.ballsLeft - 1)
        };
      });
    }, 4000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="bg-black/80 p-6 rounded-xl border-4 border-yellow-500 shadow-2xl shadow-yellow-500/20 max-w-md w-full">
      <div className="flex justify-between items-center mb-4">
        <div className="text-3xl font-black text-yellow-400 score-card">IND v AUS</div>
        <div className="bg-red-600 text-white px-3 py-1 rounded-full text-xs font-bold animate-pulse">LIVE</div>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-slate-800 p-4 rounded-lg text-center border border-slate-700">
          <div className="text-xs text-slate-400 uppercase font-bold">SCORE</div>
          <div className="text-4xl font-black">{score.runs}/{score.wickets}</div>
          <div className="text-sm text-slate-400">({score.overs} Overs)</div>
        </div>
        <div className="bg-slate-800 p-4 rounded-lg text-center border border-slate-700">
          <div className="text-xs text-slate-400 uppercase font-bold">REQUIRED</div>
          <div className="text-4xl font-black text-green-400">{score.required}</div>
          <div className="text-sm text-slate-400">from {score.ballsLeft} balls</div>
        </div>
      </div>

      <div className="mt-4 bg-yellow-400/10 p-2 rounded text-center border border-yellow-400/30">
        <span className="text-yellow-400 font-bold italic">
          CRRRRUNCH TIME! Needs {score.required} off {score.ballsLeft}!
        </span>
      </div>
    </div>
  );
};

export default Scoreboard;
