
import React, { useState } from 'react';
import { SOUND_EMOJIS } from '../constants';

const StadiumArena: React.FC = () => {
  const [reaction, setReaction] = useState<{ emoji: string; text: string } | null>(null);
  const [isShaking, setIsShaking] = useState(false);

  const triggerReaction = (text: string) => {
    const emoji = SOUND_EMOJIS[Math.floor(Math.random() * SOUND_EMOJIS.length)];
    setReaction({ emoji, text });
    setIsShaking(true);
    
    setTimeout(() => setReaction(null), 1500);
    setTimeout(() => setIsShaking(false), 500);
  };

  return (
    <div className={`relative w-full min-h-[400px] flex flex-col items-center justify-center space-y-8 p-8 stadium-gradient rounded-3xl border-8 border-slate-800 overflow-hidden ${isShaking ? 'shake' : ''}`}>
      {/* Background Crowd Effect */}
      <div className="absolute inset-0 opacity-20 pointer-events-none">
        <div className="flex flex-wrap gap-4 p-4">
          {Array.from({ length: 40 }).map((_, i) => (
            <span key={i} className={`text-2xl animate-bounce`} style={{ animationDelay: `${Math.random() * 2}s` }}>
              🙌
            </span>
          ))}
        </div>
      </div>

      <h2 className="text-5xl font-black text-white italic tracking-tighter drop-shadow-lg z-10 text-center">
        CHOOSE YOUR MOMENT! 🏏
      </h2>

      <div className="flex flex-wrap justify-center gap-6 z-10">
        <button 
          onClick={() => triggerReaction("ITS A MASSIVE SIX!!!")}
          className="group relative bg-orange-600 hover:bg-orange-500 text-white font-black px-8 py-6 rounded-2xl transform hover:scale-110 transition-all shadow-xl border-b-8 border-orange-800"
        >
          <div className="text-3xl mb-2">☄️</div>
          SUPER SIXER
          <div className="absolute -top-4 -right-4 bg-yellow-400 text-black px-2 py-1 rounded text-xs animate-bounce">+6</div>
        </button>

        <button 
          onClick={() => triggerReaction("BOWLED HIM! UNPLAYABLE!")}
          className="group relative bg-blue-600 hover:bg-blue-500 text-white font-black px-8 py-6 rounded-2xl transform hover:scale-110 transition-all shadow-xl border-b-8 border-blue-800"
        >
          <div className="text-3xl mb-2">🌪️</div>
          YORKER KING
          <div className="absolute -top-4 -right-4 bg-red-500 text-white px-2 py-1 rounded text-xs animate-pulse">WKT</div>
        </button>

        <button 
          onClick={() => triggerReaction("THAT'S PLUMB! OUT!")}
          className="group relative bg-green-600 hover:bg-green-500 text-white font-black px-8 py-6 rounded-2xl transform hover:scale-110 transition-all shadow-xl border-b-8 border-green-800"
        >
          <div className="text-3xl mb-2">☝️</div>
          DRS SHOUT
          <div className="absolute -top-4 -right-4 bg-blue-400 text-black px-2 py-1 rounded text-xs">REVIEW</div>
        </button>
      </div>

      {reaction && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/40 z-20 transition-all backdrop-blur-sm">
          <div className="text-9xl mb-4 animate-ping">{reaction.emoji}</div>
          <div className="text-6xl font-black text-yellow-400 italic text-center px-4 animate-bounce">
            {reaction.text}
          </div>
        </div>
      )}

      <div className="mt-8 text-slate-300 text-sm font-bold uppercase tracking-widest z-10">
        Feel the roar of 100,000 fans!
      </div>
    </div>
  );
};

export default StadiumArena;
