
import React from 'react';
import { COMMENTARY_MESSAGES } from '../constants';

const Ticker: React.FC = () => {
  return (
    <div className="bg-yellow-400 text-black py-2 font-bold overflow-hidden border-y-4 border-black">
      <div className="ticker-scroll flex space-x-12 uppercase tracking-widest text-lg">
        {COMMENTARY_MESSAGES.map((msg, idx) => (
          <span key={idx} className="flex items-center space-x-2">
            <span>{msg}</span>
            <span className="text-red-600">★</span>
          </span>
        ))}
        {/* Duplicate for seamless loop */}
        {COMMENTARY_MESSAGES.map((msg, idx) => (
          <span key={`dup-${idx}`} className="flex items-center space-x-2">
            <span>{msg}</span>
            <span className="text-red-600">★</span>
          </span>
        ))}
      </div>
    </div>
  );
};

export default Ticker;
