
import React from 'react';

export const COMMENTARY_MESSAGES = [
  "THAT WENT LIKE A TRACER BULLET! 🚀",
  "The crowd is absolutely ELECTRIC tonight! ⚡",
  "HE'S SMASHED THAT OUT OF THE STADIUM! 🏟️",
  "Umpire is looking at the screen... THE TENSION IS REAL! 📺",
  "A magnificent yorker! Stumps are everywhere! 🏏",
  "Who invited the guy in the chicken suit? 🐔",
  "Meme of the match: The fielder just tripped over his own shadow! 😂",
  "Last ball of the over... it's all coming down to this!",
  "DRINKS BREAK: Players are hydrated, fans are hyped! 🥤",
  "SIX! That's in the parking lot! 🚗",
];

export const RARITIES = ['Common', 'Rare', 'Epic', 'Legendary'] as const;

export const SOUND_EMOJIS = ["💥", "🔥", "📣", "🎺", "🙌", "😲"];
