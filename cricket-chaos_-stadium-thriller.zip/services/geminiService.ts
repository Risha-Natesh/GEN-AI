
import { GoogleGenAI } from "@google/genai";

export const generateCricketImage = async (prompt: string): Promise<string | null> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    // We enhance the prompt to ensure it fits the "Collectible Card/Poster" theme requested
    const enhancedPrompt = `A stunning, high-energy professional cricket collectible card design. ${prompt}. High resolution, cinematic lighting, dramatic sports photography style, vibrant colors, 4k, digital art masterpiece.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          { text: enhancedPrompt }
        ]
      },
      config: {
        imageConfig: {
          aspectRatio: "3:4"
        }
      }
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Error generating cricket image:", error);
    return null;
  }
};
