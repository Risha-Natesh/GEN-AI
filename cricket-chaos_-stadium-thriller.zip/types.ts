
export interface CricketCard {
  id: string;
  imageUrl: string;
  prompt: string;
  rarity: 'Common' | 'Rare' | 'Epic' | 'Legendary';
  stats: {
    batting: number;
    bowling: number;
    swag: number;
  };
}

export interface MatchScore {
  runs: number;
  wickets: number;
  overs: string;
  required: number;
  ballsLeft: number;
}
